The VI was created using the LabVIEW2024Q1. Using older version will not work. Make sure to install NI-ATE Core Driver from NIPM before
running the VI

Please open the LabVIEW project file to run the VI. Click on UI folder and run the Demo with UI. It should work without any problem
as long as the driver is install. 